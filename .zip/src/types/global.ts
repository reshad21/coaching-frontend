export type TQueryParam = {
    name: string;
    value: boolean | React.Key;
};