import { PaymentDashboard } from "./PaymentDashboard/PaymentDashboard";

const PaymentDetails = () => {
  return <PaymentDashboard />;
};

export default PaymentDetails;
