const ClassUpdate = () => {
  return (
    <div>
      <h1>Hello,This is ClassUpdate Route!</h1>
    </div>
  );
};

export default ClassUpdate;
