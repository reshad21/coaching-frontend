import React from 'react';

const BatchUpdate = () => {
  return (
    <div>
      <h1>Hello,This is BatchUpdate Route!</h1>
    </div>
  );
};

export default BatchUpdate;