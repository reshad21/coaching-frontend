

import Dashboard from "@/app/Dashboard/Dashboard"



export default function MainLayout() {
  return (
    <div className="w-full"> 
      <Dashboard />
    </div>
  )
}
